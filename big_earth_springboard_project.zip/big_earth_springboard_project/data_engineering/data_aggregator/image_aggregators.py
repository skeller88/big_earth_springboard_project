import imageio

import numpy as np
import xarray as xr

def load_image_bands_from_disk(base_filename):
    bands = []
    for band in ["02", "03", "04"]:
        bands.append(imageio.core.asarray(imageio.imread(base_filename.format(band), 'TIFF')))
    return np.stack(bands, axis=-1)


def load_and_write_xarray_imgs(filenames):
    imgs = np.array([load_image_bands_from_disk(filename) for filename in filenames.values])
    arr = xr.DataArray(imgs, [('name', filenames.values),
                              ('x', [num for num in range(120)]),
                              ('y', [num for num in range(120)]),
                              ('bands', ['red', 'green', 'blue']),
                              ])

    filename = f'zarr_data/imgs_{filenames.index[0]}.zarr'
    ds = xr.Dataset({'data': arr})
    return filename
